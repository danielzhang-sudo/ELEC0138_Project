Changed In app.py to implement captcha to defense data poisoning:
## New library input
from flask import send_file
from datetime import datetime, timedelta
from captcha.image import ImageCaptcha              
import random                                                      
from io import BytesIO


## Search table function define in def init_db()
cursor.execute('''CREATE TABLE IF NOT EXISTS searches(      
        search_id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        product_name TEXT,
        searches INTEGER,
        FOREIGN KEY (user_id) REFERENCES users(user_id))''')        
        db.commit()


## Check the product in def update_count(product_name):
c.execute("SELECT product_name FROM products WHERE product_name = ?", (product_name,))      
result = c.fetchone()
if result:

        conn.close()
        return True
    conn.close()
    return False


## Define required functions to generate complex captcha
# Function to generate captcha by choosing random text                                                                 
def generate_random_text(length=4):
    characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    return ''.join(random.choice(characters) for _ in range(length))

# Function to generate a random color in hexadecimal format
def random_color():
    return "#" + ''.join([random.choice('0123456789ABCDEF') for _ in range(6)])

# Function to create a captcha image with given text
def create_captcha(text):
    captcha = ImageCaptcha(width=200, height=80)
    color = random_color()
    image = captcha.create_captcha_image(text, color, (255, 255, 255))
    captcha.create_noise_dots(image, color=random_color(), number=100)
    captcha.create_noise_curve(image, color=random_color())
    
    # Save the image to a BytesIO stream rather than a file
    data = BytesIO()
    image.save(data, 'PNG')
    data.seek(0)
    return data

# Serve the captcha image via an HTTP response
def serve_captcha():
    random_text = generate_random_text(4)
    session['captcha'] = random_text
    image_data = create_captcha(random_text)
    return send_file(image_data, mimetype='image/png')


## Add required code for captcha in @app.route('/search', methods=['GET', 'POST'])
@app.route('/search', methods=['GET', 'POST'])
def search():
    username = request.cookies.get('username')

    if request.method == 'POST':
        user_captcha_response = request.form['captcha_input']                                       
        if not user_captcha_response or user_captcha_response != session.get('captcha', ''):       
            return render_template('search.html', message="Incorrect captcha, please try again.") 

        product_name = request.form['product_name']
        # use the update_count function to update the count number
        # the update_count will also return a boole value, represent whether the product exists or not
        product_exists = update_count(product_name)

        # back end transmits message back to the front end
        if product_exists:

            db = get_db()
            cursor = db.cursor()
            # Search user_id
            cursor.execute("SELECT user_id FROM users WHERE username = ?", (username,))
            user_id = cursor.fetchone()
            user_id = user_id[0]

            message = "Search is successful"

            # Try to update record
            cursor.execute('''UPDATE searches
                             SET searches = searches + 1
                             WHERE user_id = ? AND product_name = ?''', (user_id, product_name))

            # If the record does not exist, a new record is inserted
            if cursor.rowcount == 0:
                cursor.execute('''INSERT INTO searches (user_id, product_name, searches)
                                 VALUES (?, ?, ?)''', (user_id, product_name, 1))

            db.commit()
            db.close()
            return render_template('search.html', message=message)

        else:
            message = "This product doesn't exist"
            return render_template('search.html', message=message)

    return render_template('search.html')

## Add route for captcha part
@app.route('/captcha')
def captcha():
    return serve_captcha()