In this website

user could not use the search function without logging in 