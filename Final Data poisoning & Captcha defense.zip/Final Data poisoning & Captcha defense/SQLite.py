"""
Create simple database example
"""
# Import required library
import sqlite3
import csv
import os

# Connect to SQLite database
conn = sqlite3.connect("database.db")
cur = conn.cursor()

# Create product table
cur.execute("DROP TABLE IF EXISTS products;")
cur.execute("""
CREATE TABLE products (
    key INTEGER PRIMARY KEY,
    product_name TEXT,
    price INTEGER
)
""")

# Relative path to the CSV file
csv_file_path = os.path.join('product_data', 'products.csv')

# Open the CSV file and read data
with open(csv_file_path, newline='', encoding='utf-8') as csvfile:
    reader = csv.reader(csvfile)
    next(reader, None) 
    for row in reader:
        product_name, price = row
        cur.execute("INSERT INTO products (product_name, price) VALUES (?, ?)", (product_name, price))

# Commit the changes
conn.commit()

# Close connection to the database
conn.close()
