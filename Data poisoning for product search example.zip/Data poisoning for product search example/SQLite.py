"""
Create simple database example
"""
# Import required library
import sqlite3

# Connect to SQLite database
conn = sqlite3.connect("database.db")
cur = conn.cursor()

# Create product table
cur.execute("DROP TABLE IF EXISTS products;")
cur.execute("""
CREATE TABLE products (
    key INTEGER PRIMARY KEY,
    product_name TEXT,
    value INTEGER
)
""")

# Insert values into the products table
price = 10
insert_statements = []
for i in range(1, 21):
    insert_statements.append(("INSERT INTO products (product_name, value) VALUES (?, ?)", (f"P{i}", price)))
    price = price + 10
    

# Execute the insert statements
for statement, data in insert_statements:
    cur.execute(statement, data)

# Submit commit
conn.commit()

# Close connection to the database
conn.close()
